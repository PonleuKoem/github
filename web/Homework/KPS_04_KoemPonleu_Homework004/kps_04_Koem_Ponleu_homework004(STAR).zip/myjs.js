
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
                function star1() {
                    var msg = document.getElementById('warningMSG');
                    var rs = document.getElementById('rs');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    
                    
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        for (i = 1; i <= n; i++) {
                            for (j = 1; j <= i; j++) {
                                rs.innerHTML += ('* ');
                            }
                            rs.innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }


                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                function star2() {
                    var rs = document.getElementById('rs');
                    var msg = document.getElementById('warningMSG');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        for (i = n; i >= 1; i--) {
                            for (j = 1; j <= i; j++) {
                                rs.innerHTML += ('* ');
                            }
                            rs.innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }


                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                function star3() {
                    var rs = document.getElementById('rs');
                    var msg = document.getElementById('warningMSG');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        for (i = 1; i <= n; i++) {
                            for (j = i; j < n; j++) {
                                rs.innerHTML += ('...');
                            }
                            for (k = 1; k < i * 2; k++) {
                                rs.innerHTML += ('* ');
                            }
                            rs.innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }


                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                function star4() {
                    var rs = document.getElementById('rs');
                    var msg = document.getElementById('warningMSG');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        for (i = n; i >= 1; i--) {
                            for (j = n; j > i; j--) {
                                document.getElementById('rs').innerHTML += ('...');
                            }
                            for (k = 1; k < i * 2; k++) {
                                rs.innerHTML += ('* ');
                            }
                            rs.innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }


                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                function star5() {
                    var rs = document.getElementById('rs');
                    var msg = document.getElementById('warningMSG');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        if(n%2 ==0){
                            n++;
                        }
                        for (i = 1; i <= n / 2 + 1; i++) {
                            for (j = i + 1; j < n / 2 + 1; j++) {
                                rs.innerHTML += ('...');
                            }
                            for (k = 1; k < i * 2; k++) {
                                rs.innerHTML += ('* ');
                            }
                            rs.innerHTML += ('<br/>');
                        }
                        for (i = n / 2; i > 1; i--) {
                            for (j = n / 2; j >= i; j--) {
                                rs.innerHTML += ('...');
                            }
                            for (k = 1; k < i * 2 - 1; k++) {
                                rs.innerHTML += ('* ');
                            }
                            sr.innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
                function star6() {
                    var rs = document.getElementById('rs');
                    var msg = document.getElementById('warningMSG');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        if(n%2 ==0){
                            n++;
                        }
                        for (i = n / 2; i > 1; i--) {
                            for (j = n / 2 - 1; j >= i; j--) {
                                document.getElementById('rs').innerHTML += ('...');
                            }
                            document.getElementById('rs').innerHTML += ('* ');
                            document.getElementById('rs').innerHTML += ('<br/>');
                        }
                        for (i = 1; i <= n / 2 + 1; i++) {
                            for (j = i + 1; j < n / 2 + 1; j++) {
                                document.getElementById('rs').innerHTML += ('...');
                            }
                            document.getElementById('rs').innerHTML += ('* ');
                            document.getElementById('rs').innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }


                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                function star7() {
                    var rs = document.getElementById('rs');
                    var msg = document.getElementById('warningMSG');
                    rs.innerHTML= "";
                    var n = document.getElementById('txt').value;
                    var i, j;
                    if(n<=20 && n!==""){
                        msg.innerHTML="";
                        rs.innerHTML = "Generate "+n+" stars:: "+"<br /><br /><br />";
                        if(n%2 ==0){
                            n++;
                        }
                        for (i = 1; i <= n / 2 + 1; i++) {
                            for (j = i + 1; j < n / 2 + 1; j++) {
                                document.getElementById('rs').innerHTML += ('...');
                            }
                            document.getElementById('rs').innerHTML += ('* ');
                            document.getElementById('rs').innerHTML += ('<br/>');
                        }
                        for (i = n / 2; i > 1; i--) {
                            for (j = n / 2; j >= i; j--) {
                                document.getElementById('rs').innerHTML += ('...');
                            }
                            document.getElementById('rs').innerHTML += ('* ');
                            document.getElementById('rs').innerHTML += ('<br/>');
                        }
                    }else{msg.innerHTML = "Not allow empty and greater than 20!"; rs.innerHTML = "Please Try Again!";}
                }
    