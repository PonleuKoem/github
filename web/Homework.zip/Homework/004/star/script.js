function star1(){
	var x = document.getElementById("demo");
	x.innerHTML="This is place";
}
function star2(){
	
}
function star3(){
	
}
function star4(){
	
}
function star5(){
	
}
function star6(){
	
}
function star7(){
	
}