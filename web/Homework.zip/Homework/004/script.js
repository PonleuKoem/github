function tt(){
            var st = document.getElementById("start");
                  var stp = document.getElementById("stop");
            var val = document.getElementById("btn1");
            var msecPerMinute = 1000 * 60;  
            var msecPerHour = msecPerMinute * 60;  
            var msecPerDay = msecPerHour * 24;  

            // Set a date and get the milliseconds  
            var date = new Date();  
            var dateMsec = date.getTime();
            date.getHours();  
            date.getMinutes();  

            // Get the difference in milliseconds.  
            var interval = dateMsec - date.getTime();  

            // Calculate the hours, minutes.  
            var hours = Math.floor(interval / msecPerHour );  
            interval = interval - (hours * msecPerHour );  

            var minutes = Math.floor(interval / msecPerMinute );  
            interval = interval - (minutes * msecPerMinute );
            if (val.value=="Start") {
                        st.innerHTML=date.getHours()+":"+date.getMinutes();
                        val.value="Stop";
                  }else if(val.value=="Stop"){
                        stp.innerHTML=date.getHours()+":"+date.getMinutes();
                        val.value="Clear";
                        var totalDays = minutes + " minutes, ";
                        document.getElementById("dr").innerHTML=totalDays;
                  }
                  else{
                        st.innerHTML="0:00";
                        stp.innerHTML="0:00";
                        val.value="Start";
                        
                  }
	}